<p align="center">
  <img src="assets/icon-128.png" width="96" height="96" alt="熹屿 Xiyu" />
</p>

# 熹屿 Xiyu

一座为文字留白的岛 —— 面向 Halo 2.26+ 的响应式博客主题：杂志式首屏、克制的卡片流、清透的青蓝配色与柔和暗色模式，配合滑动高亮目录、文章入场动效、创作日历、友链自助申请与朋友圈订阅聚合。

- 主题标识：`theme-xiyu`
- 显示名称：熹屿 Xiyu
- 当前版本：1.0.14
- 要求：Halo `>= 2.26.0`
- 许可：[MIT](LICENSE)

## 安装

1. 下载本仓库 `dist/theme-xiyu-1.0.14.zip`（或自行构建，见下）。
2. 在 Halo 控制台进入「外观 → 主题 → 安装」，上传该 ZIP（无需解压）。
3. 安装完成后点击「启用」。
4. 进入「外观 → 主题 → 设置」按需调整各分组选项。

升级同样通过「安装」上传新版本 ZIP，Halo 会保留已有配置。

> 注意：Halo 以 `metadata.name` 作为主题身份。若你此前安装过 `theme-azure-isle`（本主题的旧标识），它无法直接升级到本包，需先卸载旧主题再安装；旧配置也不会自动迁移，可在安装后重新设置。

## 功能

- **首屏**：可自定义标题、副标题、背景图与首屏高度，支持关闭 Banner 直接进入内容。
- **文章列表**：网格 / 列表双视图切换（带过渡动画），摘要两行截断，分页保持 Halo 原生链接语义。
- **文章页**：滑动高亮目录（长目录自动跟随、不整页跳动）、代码块复制、图注、上下篇导航。
- **浮动按钮**：可选「返回顶部」或「返回文章列表」；后者仅在首页生效，点击后平滑滑到文章列表并跳过首屏 Banner，其他页面一律回到顶部。
- **作者页**：关于栏以两栏卡片呈现介绍、联系方式与社交入口。
- **友链页**：自助申请（含验证码）、站点信息、友链规则，分组紧凑卡片排版。
- **朋友圈页**（自定义模板 `friends.html`）：聚合 Halo 官方链接插件订阅的 RSS 动态。
- **暗色模式**：亮 / 暗双套配色，遵循系统偏好并可手动切换。
- **可访问性**：唯一 `h1`、地标完整、跳过导航链接、可见焦点轮廓、正文与次要文字对比度满足 WCAG AA。

## 插件兼容

| 插件 | 版本 | 用途 | 状态 |
| --- | --- | --- | --- |
| `plugin-links`（Halo 官方链接插件） | 2.5.0 | 友链、友链申请、RSS 订阅动态（朋友圈） | 推荐启用 |
| `plugin-equipment` | 1.1.1 | 装备 / 设备页 | 可选 |
| `plugin-steam` | 1.0.0 | Steam 游戏页 | 可选 |

未安装上述插件时，对应页面会给出空态提示，不影响其他页面渲染。

## 本地开发

```bash
npm install
npm run build-only   # 仅构建 templates/
npm run build        # 构建并打包 dist/theme-xiyu-<version>.zip
npm run dev          # watch 模式，边改边构建
```

模板使用 Thymeleaf 原生布局契约：页面通过 `~{layout :: html(head = ~{::head}, content = ~{::content})}` 复用 `templates/layout.html`，公共片段位于 `src/partials/`，由构建期 `<include>` 展开。

## 目录结构

```
├── src/                 # 源码（Thymeleaf 模板、partials、CSS、TS）
│   ├── partials/        # 公共片段，构建期被 include 展开
│   ├── css/main.css     # 亮/暗双套变量的主样式
│   └── js/main.ts       # 交互：导航抽屉、目录高亮、视图切换、浮动按钮等
├── public/              # 原样复制的静态资源
│   ├── assets/gateway.css
│   ├── assets/logo.svg  # 主题标识（线条版，随文字颜色变化）
│   ├── assets/favicon.svg  # 站点图标（深底圆形，未设置站点 favicon 时兜底）
│   └── error/error.html # 错误页（独立骨架）
├── assets/              # 品牌素材：icon-{512..16}.png 与 social-preview.png
├── templates/           # 构建产物：最终主题模板与哈希资源
├── dist/                # 构建产物：可安装的 ZIP
├── theme.yaml           # 主题元信息（标识、版本、配置资源名）
├── settings.yaml        # 后台设置表单（FormKit）
└── screenshot.png       # 主题预览图
```

`templates/` 与 `dist/` 已在仓库中保留一份构建结果，便于直接取用；修改 `src/` 后请重新构建，避免两者不一致。
